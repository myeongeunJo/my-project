﻿#include "Presenter.h"
// 출력 전문가

void Presenter_init()
{
	FND_init();
	LCD_init();
}

void Presenter_dispFanData(uint8_t min, uint8_t sec)
{
		
	if(sec)
	{
		FND_colonOn();
	}

	
	uint8_t fanAutoManualState;
	fanAutoManualState = Model_getfanAutoManualState();
	
	uint8_t fanWindSpeed;
	fanWindSpeed = Model_getfanWindSpeed();
	
	uint8_t fanTimerState;
	fanTimerState = Model_getfanTimerState();
	
	uint16_t timerData;
	
	//FND DISPLAY
	if(fanTimerState != TIME_OFF)
	{	
		timerData = min*100 + sec;
		FND_setFndData(timerData);
	}
	else
	{
		timerData = 0;
		FND_setFndData(timerData);
	}

	//LCD DISPLAY
	char buff[30];
	sprintf(buff, "Digital Fan!");
	LCD_writeStringXY(0, 2, buff);
	if(fanAutoManualState == MANUAL)
	{
		switch(fanWindSpeed)
		{
			case OFF :
			sprintf(buff, "  STOP   %02d:%02d", min, sec);
			LCD_writeStringXY(1, 0, buff);
			break;
			case LOW :
			sprintf(buff, "  LOW    %02d:%02d", min, sec);
			LCD_writeStringXY(1, 0, buff);
			break;
			case MEDIUM :
			sprintf(buff, "  MEDIUM %02d:%02d", min, sec);
			LCD_writeStringXY(1, 0, buff);
			break;
			case HIGH :
			sprintf(buff, "  HIGH   %02d:%02d", min, sec);
			LCD_writeStringXY(1, 0, buff);
			break;
		}
	}
	else
	{
		sprintf(buff, "  AUTO   %02d:%02d", min, sec);
		LCD_writeStringXY(1, 0, buff);
	}
		
	
	
	
}
