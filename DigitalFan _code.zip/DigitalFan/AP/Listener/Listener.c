﻿#include "Listener.h"

uint8_t fanTimeFlag;
button_t btnStop, btnSpeed, btnMode, btnTimer;				

void Listener_init()							// 버튼 초기화
{	
	//UART_init
	UART0_init();
	//Button_init
	Button_init(&btnStop, &BUTTON1_DDR, &BUTTON1_PIN, &BUTTON1_PORT, BUTTON1_PINNUM);
	Button_init(&btnSpeed, &BUTTON2_DDR, &BUTTON2_PIN, &BUTTON2_PORT, BUTTON2_PINNUM);
	Button_init(&btnMode, &BUTTON3_DDR, &BUTTON3_PIN, &BUTTON3_PORT, BUTTON3_PINNUM);
	Button_init(&btnTimer, &BUTTON4_DDR, &BUTTON4_PIN, &BUTTON4_PORT, BUTTON4_PINNUM);
}

void UART0_command()
{
	uint8_t fanAutoManualState;
	fanAutoManualState = Model_getfanAutoManualState();
	
	uint8_t fanWindSpeed;
	fanWindSpeed = Model_getfanWindSpeed();
	
	uint8_t fanTimerState;
	fanTimerState = Model_getfanTimerState();
	
	if(UART0_getRxFlag())									// UART 통신으로 제어
	{
		UART0_clearRxFlag();
		uint8_t* rxString = UART0_readRxBuff();
		
		// 풍량조절 UART
		if(fanAutoManualState == MANUAL)
		{
			if(!strcmp((char*)rxString,"fan_off\n"))
			{
				fanWindSpeed = OFF;
				Model_setfanWindSpeed(fanWindSpeed);
				printf("fan_off\n");
			}
			else if(!strcmp((char*)rxString,"fan_low\n"))
			{
				fanWindSpeed = LOW;
				Model_setfanWindSpeed(fanWindSpeed);
				printf("fan_low\n");
			}
			else if(!strcmp((char*)rxString,"fan_medium\n"))
			{
				fanWindSpeed = MEDIUM;
				Model_setfanWindSpeed(fanWindSpeed);
				printf("fan_medium\n");
			}
			else if(!strcmp((char*)rxString,"fan_high\n"))
			{
				fanWindSpeed = HIGH;
				Model_setfanWindSpeed(fanWindSpeed);
				printf("fan_high\n");
			}
		}
		
		// 타이머 UART
		if(!strcmp((char*)rxString,"time_off\n"))
		{
			fanTimerState = TIME_OFF;
			Model_setfanTimerState(fanTimerState);
			fanTimeFlag = 0;
			Model_setfanTimeFlag(fanTimeFlag);
			fanWindSpeed = OFF;   
			Model_setfanWindSpeed(fanWindSpeed);
			printf("time_off\n"); 
		}		
		if(!strcmp((char*)rxString,"time3\n"))
		{
			fanTimerState = TIME3;
			Model_setfanTimerState(fanTimerState);
			fanTimeFlag = 0;
			Model_setfanTimeFlag(fanTimeFlag);
			printf("time3\n");
		}
		else if(!strcmp((char*)rxString,"time5\n"))
		{
			fanTimerState = TIME5;
			Model_setfanTimerState(fanTimerState);
			fanTimeFlag = 0;
			Model_setfanTimeFlag(fanTimeFlag);
			printf("time5\n");
		}
		else if(!strcmp((char*)rxString,"time7\n"))
		{
			fanTimerState = TIME7;
			Model_setfanTimerState(fanTimerState);
			fanTimeFlag = 0;
			Model_setfanTimeFlag(fanTimeFlag);
			printf("time7\n");
		}
	}
}

void Listener_eventCheck()	
{	
	Listener_stopEvent();	
	Listener_modeEvent();
	Listener_timerEvent();	
}

void Listener_manualEvent()										// FAN 스피드 설정		4단계 설정 ( STOP, LOW, MEDIUM, HIGH )
{
	uint8_t fanWindSpeed;
	fanWindSpeed = Model_getfanWindSpeed();						
		
	if((Button_GetState(&btnSpeed) == ACT_RELEASED))				
	{
		fanWindSpeed = (fanWindSpeed + 1) % 4;
		Model_setfanWindSpeed(fanWindSpeed);
	}
}

void Listener_modeEvent()										// 수동, 자동 모드 설정
{	
	uint8_t fanAutoManualState;									
	fanAutoManualState = Model_getfanAutoManualState();
	
	switch(fanAutoManualState)
	{
		case MANUAL :												// 0
		Listener_manualEvent();
		if((Button_GetState(&btnMode) == ACT_RELEASED))				// 3번스위치 push
		{
			fanAutoManualState = AUTO;
			Model_setfanAutoManualState(fanAutoManualState);
		}
		break;
		case AUTO :													//1
		if((Button_GetState(&btnMode) == ACT_RELEASED))
		{
			fanAutoManualState = MANUAL;
			Model_setfanAutoManualState(fanAutoManualState);
		}
		break;
	}
}

void Listener_timerEvent()
{
	uint8_t fanWindSpeed;
	uint8_t fanAutoManualState;
	uint8_t fanTimerState;
	
	fanWindSpeed = Model_getfanWindSpeed();
	fanTimerState = Model_getfanTimerState();
	fanTimeFlag = Model_getfanTimeFlag();
	fanAutoManualState = Model_getfanAutoManualState();
	
	if((fanWindSpeed != OFF) | (fanAutoManualState == AUTO))
	{
		if((Button_GetState(&btnTimer) == ACT_RELEASED))				// 타이머 버튼이 눌리면 다음 타이머 순서로 돌림
		{
			fanTimerState = (fanTimerState + 1) % 4;					// 0,1,2,3
			Model_setfanTimerState(fanTimerState);
			fanTimeFlag = 0;
			Model_setfanTimeFlag(fanTimeFlag);							// 타이머 시간 설정 아직 안함.  -> 타이머 설정이 안됨 바로 stop이 됨
		}
	}
}

void Listener_stopEvent()
{
	uint8_t fanAutoManualState;
	fanAutoManualState = Model_getfanAutoManualState();				//
	
	uint8_t fanTimerState;
	fanTimerState = Model_getfanTimerState();						//
	
	uint8_t fanWindSpeed;
	fanWindSpeed = Model_getfanWindSpeed();
	
	if((Button_GetState(&btnStop) == ACT_RELEASED))				// 무슨 조건이든 항상 끄게
	{
		//MANUAL로 전환
		fanAutoManualState = MANUAL;
		Model_setfanAutoManualState(fanAutoManualState);		//   지우면 auto부분에서 안꺼짐
		//fan wind speed off
		fanWindSpeed = OFF;
		Model_setfanWindSpeed(fanWindSpeed);					// 바람세기 OFF
		//타이머도 OFF
		fanTimerState = TIME_OFF;								// 타이머도 끄기
		Model_setfanTimerState(fanTimerState);
	}
}

