﻿#ifndef SERVICE_FAN_H_
#define SERVICE_FAN_H_

#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>
#include <stdlib.h>

#include "../Model/Model_TimerValue.h"
#include "../Model/Model_AutoManual.h"
#include "../Model/Model_WindSpeed.h"
#include "../Presenter/Presenter.h"

#define FAN_ICR		ICR3
#define FAN_OCR		OCR3A

void Service_fanInit();
void Service_fanDecMillisec();
void Service_fanRun();

void Service_fanOff();
void Service_fanLow();
void Service_fanMedium();	
void Service_fanHigh();
void Service_fanAutoSpeed();

void Service_fanTimerConfigure();
void Service_fanTimeOver();
void Service_fanManualConfigure();
void Service_fanAutoConfigure();
void Service_fanDisplay();

#endif /* SERVICE_FAN_H_ */