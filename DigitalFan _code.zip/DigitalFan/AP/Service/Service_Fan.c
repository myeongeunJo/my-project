﻿#include "Service_Fan.h"

uint16_t fan_millisec;
uint8_t fan_sec, fan_min;


void Service_fanInit()
{
	//Time Initialize
	fan_millisec = 0;
	fan_sec = 0;
	fan_min = 0;

	
	
	//PWM Initialize
	TCCR3B |= (0<<CS32) | (1<<CS31) | (1<<CS30); // PreScaler 1/64	
	// FAST PWM mode 14
	TCCR3B |= (1<<WGM33) | (1<<WGM32);
	TCCR3A |= (1<<WGM31) | (0<<WGM30);	
	TCCR3A |= (1<<COM3A1) | (0<<COM3A0); // non-inverting mode	
	DDRE |= (1<<3);	
}

void Service_fanLow()	
{
	TCCR3A |= (1<<COM3A1) | (0<<COM3A0);  // Fast PWM 14
	FAN_ICR = (250000 / 20000) - 1;	// 20khz frequency , Top value
	FAN_OCR = FAN_ICR * 0.4;		// Duty Cycle 40%
	TCNT3 = 0;
}

void Service_fanMedium()	
{
	TCCR3A |= (1<<COM3A1) | (0<<COM3A0);
	FAN_ICR = (250000 / 20000) - 1;	// 20khz frequency , Top value
	FAN_OCR = FAN_ICR * 0.6;		// Duty Cycle 60%
	TCNT3 = 0;
}

void Service_fanHigh()	
{
	TCCR3A |= (1<<COM3A1) | (0<<COM3A0);
	FAN_ICR = (250000 / 20000) - 1;	// 20khz frequency , Top value
	FAN_OCR = FAN_ICR * 1;			// Duty Cycle 100%
	TCNT3 = 0;
}

void Service_fanOff()
{
	TCCR3A &= ~((1<<COM3A1) | (1<<COM3A0));
	TCNT3 = 0;
}

void Service_fanAutoSpeed()
{
	TCCR3A |= (1<<COM3A1) | (0<<COM3A0);
	FAN_ICR = (250000 / 20000) - 1;							// 20khz frequency , Top value
	FAN_OCR = FAN_ICR * ((double)((rand() % 6) + 5) / 10);			// Duty Cycle 50 ~ 100%
	TCNT3 = 0;
}

void Service_fanDecMillisec()							
{
	uint8_t fanTimerState;
	fanTimerState = Model_getfanTimerState();
	
	if(fan_millisec || fan_sec || fan_min)
	{
		if(fanTimerState != TIME_OFF)
		{
			if (fan_millisec > 0) {
				fan_millisec--;
				} else {
				fan_millisec = 999;
				if (fan_sec > 0) {
					fan_sec--;
					} else {
					fan_sec = 59;
					if (fan_min > 0) {
						fan_min--;
						} else {
						fan_min = 59;
					}
				}
			}
		}												
}
}

void Service_fanRun()
{
	Service_fanTimerConfigure();
	Service_fanTimeOver();
	Service_fanManualConfigure();
	Service_fanAutoConfigure();
	Service_fanDisplay();
}

void Service_fanTimerConfigure()
{
	uint8_t fanAutoManualState;
	uint8_t fanWindSpeed;
	fanWindSpeed = Model_getfanWindSpeed();
	fanAutoManualState = Model_getfanAutoManualState();	
	
	if((fanWindSpeed == OFF)&(fanAutoManualState == MANUAL))
	{
		fan_min = 0;
		fan_sec = 0;
		fan_millisec = 0;
	} 
	
	uint8_t fanTimerState;
	fanTimerState = Model_getfanTimerState();
	
	uint8_t fanTimeFlag;
	fanTimeFlag = Model_getfanTimeFlag();
	
	if(!fanTimeFlag)												// 타이머 버튼 눌릴때마다 새로 설정되게.
	{
		switch(fanTimerState)
		{
			case TIME_OFF :
			fan_min = 0;
			fan_sec = 0;
			fan_millisec = 0;
			break;
			case TIME3 :
			fan_min = 0;
			fan_sec = 10;
			fan_millisec = 0;
			break;
			case TIME5 :
			fan_min = 0;
			fan_sec = 20;
			fan_millisec = 0;
			break;
			case TIME7 :
			fan_min = 0;
			fan_sec = 30;
			fan_millisec = 0;
			break;
		}
		fanTimeFlag = 1;
		Model_setfanTimeFlag(fanTimeFlag);			// -> 없으면 숫자가 안떨어짐
	}
}

void Service_fanTimeOver()
{
	uint8_t fanAutoManualState;
	fanAutoManualState = Model_getfanAutoManualState();
	
	uint8_t fanTimerState;
	fanTimerState = Model_getfanTimerState();
	
	uint8_t fanWindSpeed;
	fanWindSpeed = Model_getfanWindSpeed();	
	
	if(fanTimerState != TIME_OFF)									// 타이머 켜져있을때
	{
		if(!(fan_millisec | fan_sec | fan_min))						// 다 0일때
		{
			//MANUAL로 전환
			fanAutoManualState = MANUAL;
			Model_setfanAutoManualState(fanAutoManualState);
			//fan wind speed off
			fanWindSpeed = OFF;
			Model_setfanWindSpeed(fanWindSpeed);					// 바람세기 OFF
			//타이머도 OFF
			fanTimerState = TIME_OFF;								// 타이머도 끄기
			Model_setfanTimerState(fanTimerState);
		}
	}
}

void Service_fanManualConfigure()
{
	uint8_t fanAutoManualState;
	fanAutoManualState = Model_getfanAutoManualState();
	
	uint8_t fanWindSpeed;
	fanWindSpeed = Model_getfanWindSpeed();
	
	if(fanAutoManualState == MANUAL)// 수동모드일때
	{
		switch(fanWindSpeed)
		{
			case OFF :
				Service_fanOff();
			break;
			case LOW :
				Service_fanLow();
			break;
			case MEDIUM :
				Service_fanMedium();
			break;
			case HIGH :
				Service_fanHigh();
			break;
		}
	}
}

void Service_fanAutoConfigure()
{
	uint8_t fanAutoManualState;
	fanAutoManualState = Model_getfanAutoManualState();
	
	if(fanAutoManualState == AUTO)// 자동 모드일때
	{
		Service_fanAutoSpeed();
	}
}

void Service_fanDisplay()
{
	Presenter_dispFanData(fan_min, fan_sec);
}